import React, { useState } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent } from './components/ui/card';
import { MapPin, Phone, Mail } from 'lucide-react';

export default function App() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    service: 'Lawn & Landscaping',
    notes: '',
    urgency: 'Normal',
    consent: false,
  });
  const [status, setStatus] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!formState.consent) {
      alert('Please agree to be contacted before submitting.');
      return;
    }
    setStatus('sending');
    try {
      const res = await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formState }),
      });
      if (!res.ok) throw new Error('Network error');
      setStatus('sent');
    } catch {
      setStatus('error');
    }
  }

  const servicesWithImages = [
    { title: 'Lawn & Landscaping', before: 'https://images.unsplash.com/photo-1592813630419-0e96f1d82d71', after: 'https://images.unsplash.com/photo-1504593811423-6dd665756598' },
    { title: 'Property Inspections', before: 'https://images.unsplash.com/photo-1581093458791-9c10ca588bbd', after: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
    { title: 'Debris Removal & Trash-Outs', before: 'https://images.unsplash.com/photo-1600585153837-7957d5d642d4', after: 'https://images.unsplash.com/photo-1581574204331-9b9b7d1f21b1' },
    { title: 'Securing & Lock Changes', before: 'https://images.unsplash.com/photo-1600585154175-5c75a2f3d12b', after: 'https://images.unsplash.com/photo-1600607687920-4e4d8b1b10c3' },
    { title: 'Winterization', before: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb', after: 'https://images.unsplash.com/photo-1600508773911-2410b4aa1f3d' },
    { title: 'Repairs & Maintenance', before: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be', after: 'https://images.unsplash.com/photo-1581093588401-22d9d3e1df2d' }
  ];

  return (
    <div className="font-sans text-gray-800">
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-20 text-center">
        <h1 className="text-4xl font-bold mb-4">EverGuard Property Services LLC</h1>
        <p className="italic mb-6">Protecting Assets, Preserving Value</p>
      </section>
      <section className="py-16 px-8">
        <h2 className="text-3xl font-semibold text-center mb-10">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {servicesWithImages.map(({ title, before, after }) => (
            <Card key={title} className="rounded-2xl shadow-md hover:shadow-xl transition">
              <CardContent className="p-4 text-center">
                <h3 className="font-semibold text-lg mb-3 text-blue-900">{title}</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div><p className="text-sm text-gray-500 mb-1">Before</p><img src={before} alt="before" className="rounded-lg h-36 w-full object-cover" /></div>
                  <div><p className="text-sm text-gray-500 mb-1">After</p><img src={after} alt="after" className="rounded-lg h-36 w-full object-cover" /></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
